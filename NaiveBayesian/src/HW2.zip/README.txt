Issue the following command to run the program:
$python Main.py

Please note that the following files must be in the same folder:
- The Main.py file,
- The SMSData.py file
- The SMS training data